package com.example.project

class DetailActivity {
}