package com.example.project

class CheckoutActivity {
}